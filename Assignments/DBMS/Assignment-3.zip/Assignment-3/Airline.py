#!/usr/bin/env python
# coding: utf-8

# In[64]:


import psycopg2
try:
    connection = psycopg2.connect(user = "postgres",
                                      password = "admin123",
                                      host = "localhost",
                                      port = "5432",
                                      database = "airline")
    cursor=connection.cursor()
    air_name=input("Enter aircraft:")
    cursor.execute("select ename from employees JOIN certified on employees.eid = certified.eid JOIN aircraft on aircraft.aid = certified.aid WHERE aname=%s",(air_name,))
    row=cursor.fetchall()
    pilot_names=[]

    for i in row:
        pilot_names.append(i[0])
    for i in pilot_names:
        print(i)
except (Exception, psycopg2.DatabaseError) as error :
    print ("Error while creating PostgreSQL table", error)
finally:
    #closing database connection.
        if(connection):
            cursor.close()
            connection.close()
            print("PostgreSQL connection is closed")


# In[ ]:




