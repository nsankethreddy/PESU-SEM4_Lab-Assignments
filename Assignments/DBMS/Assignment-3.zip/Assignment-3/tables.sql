CREATE DATABASE airline
    WITH 
    OWNER = postgres
    ENCODING = 'UTF8'
    LC_COLLATE = 'English_United States.1252'
    LC_CTYPE = 'English_United States.1252'
    TABLESPACE = pg_default
    CONNECTION LIMIT = -1;

CREATE TABLE public.aircraft
(
    aid integer NOT NULL,
    aname character varying COLLATE pg_catalog."default",
    cruisingrange integer,
    CONSTRAINT aircraft_pkey PRIMARY KEY (aid)
)

CREATE TABLE public.certified
(
    eid integer NOT NULL,
    aid integer NOT NULL,
    CONSTRAINT cert_pk PRIMARY KEY (eid, aid),
    CONSTRAINT fk1 FOREIGN KEY (eid)
        REFERENCES public.employees (eid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION,
    CONSTRAINT fk2 FOREIGN KEY (aid)
        REFERENCES public.aircraft (aid) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)


CREATE TABLE public.employees
(
    eid integer NOT NULL,
    ename character varying COLLATE pg_catalog."default",
    salary integer,
    CONSTRAINT employees_pkey PRIMARY KEY (eid)
)

CREATE TABLE public.flights
(
    flno integer NOT NULL,
    from_loc character varying(20) COLLATE pg_catalog."default",
    to_loc character varying(20) COLLATE pg_catalog."default",
    distance integer,
    departs time without time zone,
    arrives time without time zone,
    price integer,
    CONSTRAINT flights_pkey PRIMARY KEY (flno)
)

INSERT INTO FLIGHTS VALUES 
(1706, 'BLR', 'BOM', 1000, '09:10:00', '11:15:00', 4300),
(1812, 'PNQ', 'DEL', 1200, '17:00:00', '19:00:00', 6500),
(1645, 'IXZ', 'BLR', 1650, '16:15:00', '19:00:00', 8000),
(1136, 'IDR', 'CCU', 1300, '06:00:00', '08:30:00', 5600),
(1696, 'BLR', 'AMD', 1200, '18:45:00', '20:45:00', 4500);


insert into employees values 
(1,'Ramu',50000),
(2,'Cato',56000),
(3,'Man',90000),
(4,'Skete',20000),
(5,'Dogo',70000),
(6,'Tria',8666),
(7,'Asd',78787),
(8,'rew',89393),
(9,'you',909090),
(10,'ko',79654);

insert into aircraft
values (164,'Vistara',2993),(176,'SpiceJet',3141),(124,'Indigo',2990),(111,'Boeing',1300);

insert into certified values
(1,111),(2,123),(3,124),(5,111),(6,176),(7,111),(9,124);